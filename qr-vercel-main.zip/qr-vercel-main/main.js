// --- START: Prefix "274" Implementation ---
// Set the initial value of the store number input to "274"
// storeNumberInput.value = "274";

// // Prevent deleting or modifying the prefix
// storeNumberInput.addEventListener("input", () => {
//   if (!storeNumberInput.value.startsWith("274")) {
//     storeNumberInput.value = "274";
//   }
// });

// // Move cursor to the end of the input field when focused
// storeNumberInput.addEventListener("focus", () => {
//   const value = storeNumberInput.value;
//   storeNumberInput.value = ""; // Temporarily clear the value
//   storeNumberInput.value = value; // Restore the value to move the cursor to the end
// });
// // --- END: Prefix "274" Implementation ---
